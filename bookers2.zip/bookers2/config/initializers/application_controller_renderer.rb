# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd690c6dcd2310e62f27442d1c677699b82f99bee326b25d6b3a98c59bc8c390202ccef5eac22450924645bf2b1ca893a41a0e4fe786420c9af27f184eb765213'